export enum MoonPhase {
  New = "New Moon",
  WaxingCrescent = "Waxing Crescent",
  FirstQuarter = "First Quarter",
  WaxingGibbous = "Waxing Gibbous",
  Full = "Full Moon",
  WaningGibbous = "Waning Gibbous",
  LastQuarter = "Last Quarter",
  WaningCrescent = "Waning Crescent",
}

export interface InventoryItem {
  id: string;
  emoji: string;
  name: string;
  glitchName: string;
  description: string;
  glitchDescription: string;
}

export interface Quote {
  id: string;
  normal: string;
  glitch: string;
  context: string;
}

export interface DiaryEntry {
  date: string;
  title: string;
  content: string;
  hiddenContent: string; // Revealed only in Dark Mode
  isCritical: boolean;
}

export interface AppState {
  isGlitch: boolean; 
  isTranslated: boolean; 
  moonPhaseIndex: number;
  inventory: string[];
  activeSection: 'home' | 'profile' | 'catalogue' | 'shop' | 'diary' | 'mirror' | 'secret';
  isDark: boolean;
  entityEncounter: boolean;
  mirrorCracks: number; 
  isMirrorShattered: boolean; 
  isMirrorTriggered: boolean; 
  jumpScareTriggered: boolean;
  isPurchased: boolean;
  isDownloading: boolean;
  downloadProgress: number;
  showHiddenTriggered: boolean;
}

export interface ImageData {
  url: string;
  type: 'normal' | 'glitch' | 'horror' | 'ending' | 'jumpscare';
}