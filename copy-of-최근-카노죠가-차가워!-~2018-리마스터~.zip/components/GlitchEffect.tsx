import React, { useEffect, useRef } from 'react';

// Simple beep synth for glitch sounds
export const playGlitchSound = (type: 'hover' | 'click' | 'scream' = 'hover') => {
  const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
  if (!AudioContext) return;
  
  const ctx = new AudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  
  osc.connect(gain);
  gain.connect(ctx.destination);
  
  if (type === 'hover') {
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(100, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(50, ctx.currentTime + 0.1);
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
    osc.start();
    osc.stop(ctx.currentTime + 0.1);
  } else if (type === 'click') {
    osc.type = 'square';
    osc.frequency.setValueAtTime(50, ctx.currentTime);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
    osc.start();
    osc.stop(ctx.currentTime + 0.2);
  } else if (type === 'scream') {
    // White noise buffer for scream effect
    const bufferSize = ctx.sampleRate * 0.5; // 0.5 sec
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    noise.connect(gain);
    gain.gain.setValueAtTime(0.5, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
    noise.start();
  }
};

interface GlitchTextProps {
  text: string;
  isGlitch: boolean;
  className?: string;
  tag?: 'h1' | 'h2' | 'h3' | 'p' | 'span' | 'div';
}

export const GlitchText: React.FC<GlitchTextProps> = ({ text, isGlitch, className = "", tag = 'span' }) => {
  const Tag = tag as any;
  
  if (!isGlitch) {
    return <Tag className={className}>{text}</Tag>;
  }

  // Zalgo-ish generator setup (simplified)
  const corrupt = (t: string) => {
    return t.split('').map(c => Math.random() > 0.7 ? c + '\u0321\u035d\u0322' : c).join('');
  };

  return (
    <Tag 
      className={`${className} glitch-text font-serif text-red-600`} 
      data-text={text}
      onMouseEnter={() => playGlitchSound('hover')}
    >
      {corrupt(text)}
    </Tag>
  );
};
