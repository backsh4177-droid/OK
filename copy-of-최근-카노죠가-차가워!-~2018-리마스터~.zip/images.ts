import { ImageData } from './types';

export const IMAGES: ImageData[] = [
  // [USER] Add your image URLs here
  // Normal Mode Images
  { url: "https://r2.erweima.ai/i/A8mI6DjtR6W04zLwYq0mCw.png", type: 'normal' }, // Mirror Image (Smiling Front)
  { url: "https://r2.erweima.ai/i/pAt0A-n6S5Wh6_FqSREeAg.png", type: 'normal' }, // Angry/Blushing
  { url: "https://r2.erweima.ai/i/j0L_T8uORC-M2n8Nf_gDZw.png", type: 'normal' }, // Station/Indoor
  { url: "https://r2.erweima.ai/i/N_0G6H7mR-S6XwL_y9zM-A.png", type: 'normal' }, // Cafe/Eating
  { url: "https://r2.erweima.ai/i/V5uW_X-jR6yX_T6vM_y9zM.png", type: 'normal' }, // Waitress
  { url: "https://r2.erweima.ai/i/L8mI6DjtR6W04zLwYq0mCw.png", type: 'normal' }, // Sunset Snow
  
  // Glitch Mode Images
  { url: "https://r2.erweima.ai/i/S_0G6H7mR-S6XwL_y9zM-A.png", type: 'glitch' },
  { url: "https://r2.erweima.ai/i/M8mI6DjtR6W04zLwYq0mCw.png", type: 'glitch' },
  { url: "https://r2.erweima.ai/i/T_0G6H7mR-S6XwL_y9zM-A.png", type: 'glitch' },
  { url: "https://r2.erweima.ai/i/U_0G6H7mR-S6XwL_y9zM-A.png", type: 'glitch' },
  
  // Horror/Dark Mode Images
  { url: "https://r2.erweima.ai/i/K8mI6DjtR6W04zLwYq0mCw.png", type: 'horror' },
  { url: "https://r2.erweima.ai/i/R_0G6H7mR-S6XwL_y9zM-A.png", type: 'horror' },
  { url: "https://r2.erweima.ai/i/P_0G6H7mR-S6XwL_y9zM-A.png", type: 'horror' },
  
  // Ending & Jumpscare
  { url: "https://r2.erweima.ai/i/Q_0G6H7mR-S6XwL_y9zM-A.png", type: 'ending' },
  { url: "https://r2.erweima.ai/i/c1vN5xZ.png", type: 'jumpscare' } // Placeholder or specific jumpscare URL
];