import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { 
  MOON_PHASES, MOON_EMOJIS, IMAGES, LOCALIZED_QUOTES, INVENTORY_ITEMS, DIARY_ENTRIES, MIRROR_CODES, ENCOUNTER_TRUTH, ENTITY_ASCII, SHOP_DATA, CREDITS_DATA, DOWNLOAD_DATA, HIDDEN_ROOM_TEXT, PROFILE_INFO, DOWNLOAD_BLOCK_MESSAGES 
} from './constants';
import { AppState, InventoryItem } from './types';
import { GlitchText, playGlitchSound } from './components/GlitchEffect';
import { 
  ShoppingBag, Moon, BookOpen, X, ShoppingCart, User, Ghost, Search, AlertTriangle, Languages, Info, MessageCircle, CheckCircle, Download, ExternalLink, Heart, DownloadCloud, Lock, Unlock
} from 'lucide-react';

// --- Sub Components ---

const InventoryBar = ({ 
  items, 
  inventory, 
  onAddItem, 
  onInspectItem,
  isGlitch,
  isEntityEncounter,
  onReset 
}: { 
  items: InventoryItem[], 
  inventory: string[], 
  onAddItem: (id: string) => void,
  onInspectItem: (id: string) => void,
  isGlitch: boolean,
  isEntityEncounter: boolean,
  onReset: () => void
}) => {
  return (
    <div className={`fixed bottom-0 left-0 right-0 p-3 sm:p-4 transition-all duration-500 z-50 ${isGlitch ? (isEntityEncounter ? 'bg-red-900/90 border-t-8 border-red-600 teeth-border' : 'bg-gray-900/90 border-t-2 border-red-500') : 'bg-pink-100/90 border-t-4 border-pink-300'}`}>
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {items.map(item => {
            const inStock = inventory.includes(item.id);
            // In glitch mode, we interact to add items. In normal mode (not glitch, not entity), we interact to inspect.
            // When Entity encounter is active, items might be disabled or just decorative.
            const isClickable = !isEntityEncounter; 

            return (
              <button
                key={item.id}
                onClick={() => {
                  if (isGlitch) {
                    onAddItem(item.id);
                  } else {
                    onInspectItem(item.id);
                  }
                }}
                disabled={inStock || !isClickable}
                className={`
                  p-2 sm:p-3 rounded-lg text-xl sm:text-2xl transition-all relative group shrink-0
                  ${inStock ? 'opacity-30 grayscale cursor-not-allowed' : (isClickable ? 'hover:scale-110 active:scale-95 cursor-pointer' : 'opacity-50 cursor-not-allowed grayscale')}
                  ${isGlitch ? 'hover:bg-red-900 text-white' : 'hover:bg-pink-200 bg-white shadow-sm'}
                `}
                onMouseEnter={() => isGlitch && !inStock && playGlitchSound('hover')}
              >
                {item.emoji}
                {!inStock && isGlitch && (
                  <div className={`
                    absolute bottom-full mb-3 left-1/2 -translate-x-1/2 w-40 sm:w-48 p-2 sm:p-3 text-[10px] sm:text-xs rounded pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-50 shadow-2xl
                    bg-black text-red-500 border border-red-500 font-serif
                  `}>
                     <strong className="block mb-1 text-xs sm:text-sm">{item.glitchName}</strong>
                     {item.glitchDescription}
                  </div>
                )}
              </button>
            );
          })}
        </div>
        
        <div 
          className={`
            w-12 h-12 sm:w-16 sm:h-16 border-2 border-dashed flex items-center justify-center rounded-full shrink-0 transition-all duration-300 relative
            ${isEntityEncounter ? 'border-red-500 bg-red-950 animate-pulse cursor-pointer' : 'border-gray-400 cursor-default'}
          `}
          onClick={isEntityEncounter ? onReset : undefined}
        >
          {isEntityEncounter ? (
            <div className="flex flex-col items-center justify-center">
               <Ghost className="text-red-500 w-6 h-6 sm:w-8 sm:h-8 animate-bounce" />
               <span className="text-[6px] text-red-500 font-serif absolute -bottom-4 font-bold">RESET</span>
            </div>
          ) : (
            <>
              <ShoppingCart className={`w-5 h-5 sm:w-6 sm:h-6 ${isGlitch ? "text-red-400" : "text-pink-400"}`} />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] rounded-full w-4 h-4 sm:w-5 sm:h-5 flex items-center justify-center">
                {inventory.length}
              </span>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [state, setState] = useState<AppState>({
    isGlitch: false,
    isTranslated: false,
    moonPhaseIndex: 0, 
    inventory: [],
    activeSection: 'home',
    isDark: false,
    entityEncounter: false,
    mirrorCracks: 0,
    isMirrorShattered: false,
    isMirrorTriggered: false,
    jumpScareTriggered: false,
    isPurchased: false,
    isDownloading: false,
    downloadProgress: 0,
    showHiddenTriggered: false
  });

  const [showShopModal, setShowShopModal] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [glitchMessage, setGlitchMessage] = useState<string | null>(null);
  const [blockMessage, setBlockMessage] = useState<string | null>(null);
  const [mirrorInput, setMirrorInput] = useState("");
  const [collectedMirrorCodes, setCollectedMirrorCodes] = useState<string[]>([]);
  const [showBdayHint, setShowBdayHint] = useState(false);
  const [recentMoonClick, setRecentMoonClick] = useState(false);
  const [talkIndex, setTalkIndex] = useState(0);
  const [isProfileExpanded, setIsProfileExpanded] = useState(false);
  const [bloodSplatter, setBloodSplatter] = useState(false);

  // Blaming text effect for timeline
  const [blameVisible, setBlameVisible] = useState(false);
  useEffect(() => {
    if (state.entityEncounter) {
      const interval = setInterval(() => {
        setBlameVisible(prev => !prev);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [state.entityEncounter]);

  // Shop specific states
  const [shopInputs, setShopInputs] = useState({ id: '', pw: '', card: '' });
  const [termsScrolled, setTermsScrolled] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const termsRef = useRef<HTMLDivElement>(null);

  // --- Mode Detection ---
  const currentMode = state.entityEncounter ? 'glitch' : (state.isGlitch ? 'glitch' : (state.isDark ? 'dark' : 'normal'));
  const profileMode = state.isGlitch ? 'glitch' : (state.isDark ? 'dark' : 'normal');
  const shopMode = state.entityEncounter ? 'entity' : (state.isGlitch ? 'glitch' : (state.isDark ? 'dark' : 'normal')) as keyof typeof SHOP_DATA.KR;
  const currentCredits = CREDITS_DATA[currentMode];
  const currentDownload = DOWNLOAD_DATA[currentMode];

  // --- Dialogue Logic ---
  const getCurrentDialogue = useMemo(() => {
    const lang = state.isTranslated ? "JP" : "KR";
    const quotes = LOCALIZED_QUOTES[lang];

    if (state.entityEncounter) return quotes.encounter;
    
    if (recentMoonClick) {
        return state.moonPhaseIndex === 4 ? quotes.fullMoon : quotes.moonRising;
    }

    let currentQuotes = quotes.normal;
    if (state.isGlitch) currentQuotes = quotes.glitch;
    else if (state.isDark) currentQuotes = quotes.dark;

    const totalNormal = currentQuotes.length;
    const currentIdx = (state.moonPhaseIndex + talkIndex) % totalNormal;
    return glitchMessage || currentQuotes[currentIdx];
  }, [state.isTranslated, state.entityEncounter, state.isGlitch, state.isDark, state.moonPhaseIndex, glitchMessage, recentMoonClick, talkIndex]);

  // --- Logic Helpers ---

  const handleMoonClick = () => {
    if (state.entityEncounter) return;
    setRecentMoonClick(true);
    setTimeout(() => setRecentMoonClick(false), 5000);
    setState(prev => {
      const nextPhase = (prev.moonPhaseIndex + 1) % 8;
      if (prev.isMirrorTriggered && nextPhase === 4) {
          // Now allowed to unlock via button
      }
      return { ...prev, moonPhaseIndex: nextPhase };
    });
  };

  const handleTalkClick = () => {
    playGlitchSound('click');
    setTalkIndex(prev => prev + 1);
  };

  const handleEncounterToggle = () => {
    if (state.moonPhaseIndex !== 4) {
      playGlitchSound('click');
      alert("보름달이 뜰 때까지는 잠겨 있습니다.");
      return;
    }

    if (state.isMirrorTriggered) {
      playGlitchSound('scream');
      setState(prev => ({ ...prev, isGlitch: !prev.isGlitch, isTranslated: true }));
    } else {
      playGlitchSound('click');
      setState(prev => ({ ...prev, isTranslated: !prev.isTranslated }));
    }
  };

  const handleDownloadClick = () => {
    if (state.isPurchased) {
      setShowDownloadModal(true);
    } else {
      playGlitchSound(state.isGlitch ? 'click' : 'hover');
      const mode = state.entityEncounter ? 'entity' : (state.isGlitch ? 'glitch' : (state.isDark ? 'dark' : 'normal'));
      setBlockMessage(DOWNLOAD_BLOCK_MESSAGES[mode as keyof typeof DOWNLOAD_BLOCK_MESSAGES]);
    }
  };

  const handleAddItem = (id: string) => {
    if (!state.isGlitch || state.entityEncounter) return;
    const item = INVENTORY_ITEMS.find(i => i.id === id);
    if (item) {
        setGlitchMessage(item.glitchDescription);
        setTimeout(() => setGlitchMessage(null), 3000);
    }
    setState(prev => {
      const newInventory = [...prev.inventory, id];
      if (newInventory.length >= 6) {
          playGlitchSound('scream');
          return { ...prev, inventory: newInventory, entityEncounter: true, isMirrorShattered: true };
      }
      return { ...prev, inventory: newInventory };
    });
  };

  const handleInspectItem = (id: string) => {
    // Only works in normal/dark mode when not entity encounter
    if (state.entityEncounter) return;
    
    const item = INVENTORY_ITEMS.find(i => i.id === id);
    if (item) {
        playGlitchSound('click');
        setGlitchMessage(`${item.emoji} ${item.name}: ${item.description}`);
        setTimeout(() => setGlitchMessage(null), 3000);
    }
  };

  const handleEntityReset = () => {
    playGlitchSound('scream');
    setState({
      isGlitch: false,
      isTranslated: false,
      moonPhaseIndex: 0, 
      inventory: [],
      activeSection: 'home',
      isDark: false,
      entityEncounter: false,
      mirrorCracks: 0,
      isMirrorShattered: false,
      isMirrorTriggered: false,
      jumpScareTriggered: false,
      isPurchased: false,
      isDownloading: false,
      downloadProgress: 0,
      showHiddenTriggered: false
    });
    setCollectedMirrorCodes([]);
    setShowBdayHint(false);
    setIsProfileExpanded(false);
    setBloodSplatter(false);
    setShopInputs({ id: '', pw: '', card: '' });
    setTermsScrolled(false);
    setTermsAccepted(false);
    alert("루프가 초기화되었습니다.");
  };

  const handleMirrorInputSubmit = () => {
    const input = mirrorInput.replace(/[^0-9]/g, '');
    if (MIRROR_CODES.includes(input) && !collectedMirrorCodes.includes(input)) {
        playGlitchSound('click');
        const newCodes = [...collectedMirrorCodes, input];
        setCollectedMirrorCodes(newCodes);
        setMirrorInput("");
        const newCracks = newCodes.length;
        setState(p => ({ ...p, mirrorCracks: newCracks }));
        if (newCracks === 3) setShowBdayHint(true);
        if (newCracks >= 4) {
            playGlitchSound('scream');
            setState(p => ({ ...p, isMirrorTriggered: true, isDark: true }));
            alert(state.isTranslated ? "鏡が割れました. 満月を確認してください." : "거울이 깨졌습니다. 이제 보름달을 확인하세요.");
        }
    } else {
        const msg = state.isDark 
          ? (state.isTranslated ? "誰を見てるの?" : "누굴 보는 거야?") 
          : (state.isTranslated ? "那由は可愛かったでしょ?" : "나유가 이쁘게 생기긴 했지?");
        setGlitchMessage(msg);
        setTimeout(() => setGlitchMessage(null), 3000);
        setMirrorInput("");
    }
  };

  const handleTermsScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    if (Math.abs(target.scrollHeight - target.scrollTop - target.clientHeight) < 5) {
      setTermsScrolled(true);
    }
  };

  const handlePurchase = () => {
    if (shopInputs.id.trim() && shopInputs.pw.trim() && shopInputs.card.trim() && (state.entityEncounter || termsAccepted)) {
      playGlitchSound('click');
      setState(prev => ({ ...prev, isPurchased: true, showHiddenTriggered: true }));
      alert(SHOP_DATA.KR[shopMode].thanks);
      // Automatically trigger download after purchase
      setTimeout(() => setShowDownloadModal(true), 1500);
    }
  };

  const handleStartDownload = () => {
    if (state.downloadProgress === 100) return;
    playGlitchSound('click');
    setState(p => ({ ...p, isDownloading: true, downloadProgress: 0 }));
    let prog = 0;
    const interval = setInterval(() => {
        prog += Math.random() * 15;
        if (prog >= 100) {
            prog = 100;
            clearInterval(interval);
            setState(p => ({ ...p, isDownloading: false, downloadProgress: 100 }));
            playGlitchSound('hover');
        } else {
            setState(p => ({ ...p, downloadProgress: prog }));
        }
    }, 400);
  };

  const currentVisual = useMemo(() => {
    if (state.jumpScareTriggered) return IMAGES.find(i => i.type === 'jumpscare')?.url || "";
    if (state.entityEncounter) return IMAGES.find(i => i.type === 'ending')?.url || "";
    
    if (state.isGlitch) {
        const glitchImages = IMAGES.filter(i => i.type === 'glitch');
        if (glitchImages.length === 0) return "";
        return glitchImages[state.moonPhaseIndex % glitchImages.length].url;
    }
    
    if (state.isDark) {
        const horrorImages = IMAGES.filter(i => i.type === 'horror');
        if (horrorImages.length === 0) return "";
        return horrorImages[state.moonPhaseIndex % horrorImages.length].url;
    }

    const normalImages = IMAGES.filter(i => i.type === 'normal');
    if (normalImages.length === 0) return "";
    return normalImages[state.moonPhaseIndex % normalImages.length].url;
  }, [state.isGlitch, state.isDark, state.moonPhaseIndex, state.entityEncounter, state.jumpScareTriggered]);

  const handleProfileImageClick = () => {
    if (state.entityEncounter) return;
    if (state.isGlitch) {
      setIsProfileExpanded(true);
      playGlitchSound('scream');
      setBloodSplatter(true);
      setTimeout(() => {
        setIsProfileExpanded(false);
        setBloodSplatter(false);
        setState(p => ({ ...p, activeSection: 'home' }));
      }, 1500);
    } else {
      setIsProfileExpanded(!isProfileExpanded);
      playGlitchSound('hover');
    }
  };

  const hiddenMsg = state.entityEncounter ? HIDDEN_ROOM_TEXT.entity : (state.isGlitch ? HIDDEN_ROOM_TEXT.glitch : (state.isDark ? HIDDEN_ROOM_TEXT.dark : HIDDEN_ROOM_TEXT.normal));

  const renderHome = () => (
    <div className="max-w-2xl mx-auto p-4 flex flex-col items-center gap-6">
      <div 
        onClick={handleTalkClick}
        className={`relative w-full aspect-[4/5] sm:aspect-square rounded-2xl overflow-hidden border-8 transition-all duration-700 cursor-pointer group
          ${state.isDark ? 'border-red-900 shadow-[0_0_30px_rgba(153,27,27,0.4)]' : 'border-white shadow-xl shadow-pink-200'}
          ${state.isGlitch ? 'animate-pulse' : 'hover:scale-[1.01]'}
        `}
      >
        <img 
          src={currentVisual} 
          className={`w-full h-full object-cover transition-transform duration-1000 ${state.isGlitch ? 'scale-110' : 'group-hover:scale-105'}`} 
          alt="Nayu" 
        />
        {bloodSplatter && <div className="absolute inset-0 bg-red-900/40 mix-blend-multiply animate-pulse pointer-events-none" />}
        
        {/* Dialogue Box */}
        <div className={`absolute bottom-6 left-6 right-6 p-4 sm:p-6 rounded-xl backdrop-blur-md border-2 transition-all duration-500
          ${state.isDark ? 'bg-black/80 border-red-900 text-red-500 font-serif' : 'bg-white/90 border-pink-200 text-gray-800 font-cute shadow-lg'}
        `}>
           <p className="text-sm sm:text-lg leading-relaxed text-center">
             <GlitchText text={getCurrentDialogue} isGlitch={state.isGlitch} />
           </p>
        </div>
      </div>

      {state.showHiddenTriggered && (
        <div className={`w-full p-4 rounded-lg border border-dashed transition-all ${state.isDark ? 'bg-red-950/20 border-red-900 text-red-500' : 'bg-black/5 border-gray-300 text-gray-600'}`}>
           <p className="text-xs text-center opacity-70 italic">{hiddenMsg}</p>
        </div>
      )}

      {showBdayHint && !state.entityEncounter && (
        <div className="bg-red-900/10 border border-red-900/20 p-3 rounded text-[10px] text-red-800 animate-pulse text-center">
          "0116... 그날의 폐가를 기억해?"
        </div>
      )}
    </div>
  );

  return (
    <div className={`min-h-screen flex flex-col transition-all duration-700 overflow-x-hidden ${state.isDark ? 'dark bg-gray-950 text-gray-100' : 'bg-pink-50 text-gray-800'}`}>
      {state.isMirrorTriggered && <div className="cracked-screen-overlay pointer-events-none" />}
      {(state.isGlitch || state.entityEncounter) && <div className="fixed inset-0 pointer-events-none z-0 blood-drip opacity-50"></div>}
      
      <header className={`sticky top-0 z-40 backdrop-blur-md border-b px-4 h-16 flex items-center justify-between ${state.isDark ? 'bg-gray-900/80 border-gray-700 shadow-lg shadow-red-900/20' : 'bg-white/80 border-pink-200'}`}>
        <div className="flex items-center gap-2 overflow-hidden">
            <h1 onClick={() => setState(p => ({ ...p, activeSection: 'home' }))} className={`text-[10px] sm:text-lg font-bold cursor-pointer transition-all whitespace-nowrap ${state.isDark ? 'text-red-600 font-serif blood-drip' : 'text-pink-500 font-cute'}`}>
                "최근 카노죠가 차가워!" ~2018 리마스터~
            </h1>
        </div>
        
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button onClick={handleDownloadClick} className="p-2 text-pink-500 hover:scale-110 transition-transform"><DownloadCloud size={20} /></button>
            <a href="https://share.crack.wrtn.ai/jxhnyi" target="_blank" rel="noreferrer" className="p-2 text-pink-500 hover:scale-110 transition-transform"><ExternalLink size={20} /></a>
            <button 
              onClick={handleEncounterToggle} 
              className={`flex items-center gap-1 px-2 py-1 rounded-full text-[8px] sm:text-xs font-bold border transition-all 
                ${state.moonPhaseIndex === 4 ? (state.isMirrorTriggered ? 'bg-red-600 border-red-900 text-white animate-pulse' : 'bg-white border-pink-300 text-pink-500') : 'bg-gray-200 text-gray-400 cursor-not-allowed'}
              `}
            >
                {state.moonPhaseIndex === 4 ? <Unlock size={14} className="hidden sm:inline" /> : <Lock size={14} className="hidden sm:inline" />}
                {state.moonPhaseIndex === 4 ? (state.isGlitch ? "STOP" : (state.isTranslated ? "JP" : "KR")) : "LOCKED"}
            </button>
            <button onClick={() => !state.isMirrorTriggered && setState(p => ({ ...p, isDark: !p.isDark }))} className="p-2">
                {state.isDark ? <Moon size={18} className="text-red-500" /> : <span className="text-yellow-500 text-lg">☀</span>}
            </button>
            <button onClick={handleMoonClick} className="text-xl sm:text-2xl hover:scale-110 transition-transform cursor-pointer">{MOON_EMOJIS[state.moonPhaseIndex]}</button>
        </div>
      </header>

      <nav className={`flex justify-around p-2 border-b text-[10px] sm:text-xs font-bold ${state.isDark ? 'bg-gray-900 border-gray-700' : 'bg-pink-100/50 border-pink-200'}`}>
          <button onClick={() => setState(p => ({ ...p, activeSection: 'profile' }))} className="hover:text-pink-500 flex flex-col items-center"><User size={16} /> Profile</button>
          <button onClick={() => setState(p => ({ ...p, activeSection: 'diary' }))} className="hover:text-pink-500 flex flex-col items-center"><BookOpen size={16} /> {state.entityEncounter ? "Truth" : "Timeline"}</button>
          <button onClick={() => setState(p => ({ ...p, activeSection: 'mirror' }))} className="hover:text-pink-500 flex flex-col items-center"><Search size={16} /> Mirror</button>
          <button onClick={() => setShowShopModal(true)} className="hover:text-pink-500 flex flex-col items-center"><ShoppingBag size={16} /> Shop</button>
          <button onClick={() => setShowSupportModal(true)} className="hover:text-pink-500 flex flex-col items-center text-red-400"><Heart size={16} /> Support</button>
      </nav>

      <main className="flex-grow pb-32">
         {state.activeSection === 'home' && renderHome()}
         {state.activeSection === 'profile' && (
           <div className="max-w-xl mx-auto p-4 flex flex-col gap-6">
               {state.entityEncounter ? (
                   <div className="space-y-6">
                       <div className="aspect-[3/4] rounded-lg overflow-hidden border-4 border-red-900 bg-black flex items-center justify-center p-4 animate-truth">
                           <pre className="text-red-600 font-mono text-[8px] sm:text-xs leading-none whitespace-pre animate-pulse">{ENTITY_ASCII}</pre>
                       </div>
                       <div className="p-6 bg-black border-2 border-red-900 rounded-lg text-red-600 font-serif space-y-4">
                           <h2 className="text-2xl font-black">{ENCOUNTER_TRUTH.profile.title}</h2>
                           <p className="text-lg italic font-bold">{ENCOUNTER_TRUTH.profile.content}</p>
                           <div className="border-t border-red-900 pt-4"><p className="text-sm leading-relaxed">{ENCOUNTER_TRUTH.profile.note}</p></div>
                       </div>
                   </div>
               ) : (
                   <>
                       <div onClick={handleProfileImageClick} className={`cursor-pointer relative aspect-[3/4] rounded-lg overflow-hidden border-4 transition-all duration-500 ${state.isDark ? 'border-red-900' : (state.isGlitch ? 'border-red-600 shake-hard' : 'border-pink-200')} ${isProfileExpanded ? 'fixed inset-4 z-[100] sm:static sm:h-auto sm:w-full' : ''}`}>
                           <img src={currentVisual} className="w-full h-full object-cover" alt="Profile" />
                       </div>
                       {!isProfileExpanded && (
                         <div className="space-y-4">
                             <div className="border-b pb-4 border-dashed border-gray-300 dark:border-red-900">
                                <h2 className={`text-3xl font-bold ${state.isDark ? 'text-red-600 font-serif' : 'text-pink-600 font-cute'}`}>
                                  {PROFILE_INFO[profileMode as keyof typeof PROFILE_INFO]?.name}
                                </h2>
                                <p className="text-sm opacity-60 font-serif mt-1">{PROFILE_INFO[profileMode as keyof typeof PROFILE_INFO]?.subName}</p>
                             </div>
                             
                             <div className="p-4 rounded-lg bg-white/50 dark:bg-black/30 backdrop-blur-sm border border-pink-100 dark:border-red-900/50">
                                <p className={`text-sm leading-relaxed whitespace-pre-line ${state.isDark ? 'text-red-400' : 'text-gray-700'}`}>
                                  {PROFILE_INFO[profileMode as keyof typeof PROFILE_INFO]?.introduction}
                                </p>
                             </div>

                             <div className="grid gap-2">
                                {PROFILE_INFO[profileMode as keyof typeof PROFILE_INFO]?.specs.map((spec, idx) => (
                                  <div key={idx} className={`flex justify-between items-center text-xs sm:text-sm p-2 rounded ${idx % 2 === 0 ? 'bg-pink-50/50 dark:bg-red-900/10' : ''}`}>
                                    <span className="font-bold opacity-70">{spec.label}</span>
                                    <span className="text-right font-medium">{spec.value}</span>
                                  </div>
                                ))}
                             </div>
                         </div>
                       )}
                   </>
               )}
           </div>
         )}
         {state.activeSection === 'diary' && (
           <div className="max-w-2xl mx-auto p-4 space-y-6 relative overflow-hidden">
               {state.entityEncounter && blameVisible && (
                 <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-50">
                    <div className="text-red-600 font-serif text-4xl sm:text-7xl font-black opacity-30 animate-pulse rotate-12">네가 죽였어.</div>
                 </div>
               )}
               {state.entityEncounter && !blameVisible && (
                 <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-50">
                    <div className="text-red-600 font-serif text-4xl sm:text-7xl font-black opacity-30 animate-pulse -rotate-12">왜 버렸어?</div>
                 </div>
               )}

               <h2 className={`text-xl font-bold text-center mb-4 ${state.isDark ? 'text-red-500' : 'text-pink-500'}`}>{state.entityEncounter ? "ENTITY_TIMELINE" : "Timeline Records"}</h2>
               {state.entityEncounter ? (
                 ENCOUNTER_TRUTH.timeline.map((entry, idx) => (
                    <div key={idx} className="p-4 rounded-lg border-2 bg-black border-red-900 text-red-600 font-serif mb-4 shadow-[0_0_10px_rgba(255,0,0,0.5)] animate-truth">
                        <span className="text-xs font-bold opacity-60">{entry.date}</span>
                        <h3 className="font-bold mb-1">{entry.title}</h3>
                        <p className="text-sm italic">{entry.content}</p>
                    </div>
                 ))
               ) : (
                 DIARY_ENTRIES.map((entry, idx) => {
                   const isHint = state.isDark && ["01/16", "01/17", "01/18"].includes(entry.date);
                   return (
                     <div key={idx} className={`p-4 rounded-lg border-2 transition-all relative ${state.isDark ? 'bg-gray-800 border-gray-700 text-gray-200' : 'bg-white border-pink-100 text-gray-700'}`}>
                         {isHint && <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-600 rounded-full animate-pulse shadow-lg" />}
                         <span className="text-xs font-bold opacity-60">{entry.date}</span>
                         <h3 className="font-bold mb-1">{entry.title}</h3>
                         <p className="text-sm">{state.isDark ? entry.hiddenContent : entry.content}</p>
                     </div>
                   );
                 })
               )}
           </div>
         )}
         {state.activeSection === 'mirror' && (
           <div className="flex flex-col items-center justify-center p-8">
               <div className="flex gap-4 mb-4">
                  {[0,1,2,3].map(i => (
                    <div key={i} className={`w-3 h-3 rounded-full border border-white/20 shadow-md ${i < collectedMirrorCodes.length ? 'bg-red-600 animate-pulse shadow-[0_0_8px_red]' : 'bg-gray-300 dark:bg-gray-800'}`} />
                  ))}
               </div>
               <div className={`relative w-48 h-64 rounded-full border-8 transition-all duration-1000 ${state.isMirrorTriggered ? 'border-red-900 bg-black' : 'border-gray-300 bg-gray-100'}`}>
                   {!state.isMirrorTriggered && <img src={IMAGES[0]?.url || ""} className="w-full h-full object-cover opacity-40 grayscale" alt="Mirror" />}
                   {state.mirrorCracks > 0 && <div className="absolute inset-0 cracked-screen opacity-80" />}
                   {state.isMirrorTriggered && <div className="absolute inset-0 flex items-center justify-center text-red-600 font-serif text-3xl animate-pulse">침식</div>}
               </div>
               <div className="mt-6 flex flex-col items-center gap-3">
                  <p className="text-xs text-gray-500 font-cute text-center max-w-[200px]">
                    {state.isMirrorTriggered ? "거울이 깨졌습니다... 이제 보름달을 확인하세요." : "거울에 비친 날짜를 입력하여 진실의 조각을 맞추세요. (MMDD)"}
                  </p>
                  {!state.isMirrorTriggered && (
                      <div className="flex gap-2">
                          <input type="text" value={mirrorInput} maxLength={4} placeholder="MMDD" onChange={e => setMirrorInput(e.target.value)} className="border-2 border-pink-200 p-2 rounded text-center w-32 text-black outline-none focus:border-pink-500" />
                          <button onClick={handleMirrorInputSubmit} className="bg-pink-500 text-white p-2 rounded hover:bg-pink-600 transition-colors"><Search /></button>
                      </div>
                  )}
               </div>
           </div>
         )}
      </main>

      {/* --- Modals --- */}
      {blockMessage && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/60 p-4" onClick={() => setBlockMessage(null)}>
            <div className={`max-w-sm w-full p-6 rounded-xl relative shadow-2xl ${state.isGlitch ? 'bg-black border-4 border-red-600 text-red-500 font-mono shake-hard' : (state.isDark ? 'bg-gray-900 border border-gray-600 text-gray-200 font-serif' : 'bg-white border-4 border-pink-300 text-gray-800 font-cute animate-bounce')}`} onClick={e => e.stopPropagation()}>
                <button onClick={() => setBlockMessage(null)} className="absolute top-2 right-2 hover:scale-110 transition-transform"><X /></button>
                <div className="text-center space-y-4">
                    {state.isGlitch || state.entityEncounter ? <AlertTriangle size={48} className="mx-auto animate-pulse" /> : <MessageCircle size={48} className={`mx-auto ${state.isDark ? 'text-red-500' : 'text-pink-400'}`} />}
                    <p className="whitespace-pre-line text-lg leading-relaxed">{blockMessage}</p>
                    <button onClick={() => { setBlockMessage(null); setShowShopModal(true); }} className={`px-4 py-2 rounded-full font-bold transition-all ${state.isGlitch ? 'bg-red-900 text-white hover:bg-red-800' : (state.isDark ? 'bg-gray-700 hover:bg-gray-600' : 'bg-pink-100 text-pink-600 hover:bg-pink-200')}`}>
                      상점으로 이동하기
                    </button>
                </div>
            </div>
        </div>
      )}

      {showDownloadModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4">
            <div className={`max-w-md w-full p-8 rounded-2xl relative shadow-2xl transition-all ${state.isDark ? 'bg-gray-900 text-red-500 border border-red-900' : 'bg-white border-4 border-pink-300'}`}>
                <button onClick={() => setShowDownloadModal(false)} className="absolute top-4 right-4"><X /></button>
                <h3 className={`text-2xl font-black mb-6 text-center ${state.isGlitch ? 'animate-pulse' : ''}`}>{currentDownload.title}</h3>
                
                {state.downloadProgress === 100 ? (
                    <div className="text-center space-y-6">
                        <CheckCircle size={64} className="mx-auto text-green-500 animate-bounce" />
                        <div className="p-4 bg-pink-50 rounded-lg">
                            <p className="font-bold text-lg text-pink-600 mb-2">{currentDownload.complete}</p>
                            <a href={currentDownload.link} target="_blank" rel="noreferrer" className="text-blue-500 underline break-all flex items-center justify-center gap-2">{currentDownload.link} <ExternalLink size={14} /></a>
                        </div>
                    </div>
                ) : (
                    <div className="space-y-6">
                        {state.isDownloading ? (
                            <div className="space-y-2">
                                <p className="text-xs italic text-center animate-pulse">{currentDownload.progress}</p>
                                <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden">
                                    <div className={`h-full transition-all duration-300 ${state.isDark ? 'bg-red-600' : 'bg-pink-500'}`} style={{ width: `${state.downloadProgress}%` }} />
                                </div>
                            </div>
                        ) : (
                            <button onClick={handleStartDownload} className={`w-full py-4 rounded-xl font-bold text-xl flex items-center justify-center gap-2 transform active:scale-95 transition-all shadow-lg ${state.isDark ? 'bg-red-900 text-white' : 'bg-pink-500 text-white hover:bg-pink-600'}`}>
                                <Download /> {currentDownload.button}
                            </button>
                        )}
                    </div>
                )}
            </div>
        </div>
      )}

      {showSupportModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4">
              <div className={`max-w-lg w-full p-8 rounded-3xl relative overflow-hidden transition-all ${state.isGlitch ? 'bg-black border-4 border-red-900 text-red-600 font-serif' : (state.isDark ? 'bg-gray-900 text-white border border-gray-700' : 'bg-white border-4 border-pink-200')}`}>
                  <button onClick={() => setShowSupportModal(false)} className="absolute top-4 right-4 z-10"><X /></button>
                  <div className="text-center mb-6">
                      <h3 className="text-2xl font-black mb-2 flex items-center justify-center gap-2"><Heart className="text-red-500 fill-red-500" /> 나유의 후원자</h3>
                      <p className={`text-sm italic p-3 rounded-lg ${state.isDark ? 'bg-red-900/20' : 'bg-pink-50 text-pink-600'}`}>
                          {currentCredits.message}
                      </p>
                  </div>
                  <div className={`grid grid-cols-2 gap-x-4 gap-y-3 text-[10px] sm:text-xs border-t pt-4 ${state.isDark ? 'border-red-900/50' : 'border-pink-100'}`}>
                      <div><strong className="opacity-60">개발자:</strong> {currentCredits.developer}</div>
                      <div><strong className="opacity-60">히로인:</strong> {currentCredits.heroine}</div>
                      <div><strong className="opacity-60">플레이어:</strong> {currentCredits.player}</div>
                      <div><strong className="opacity-60">일러스트:</strong> {currentCredits.illust}</div>
                      <div><strong className="opacity-60">프롬프트:</strong> {currentCredits.prompt}</div>
                      <div><strong className="opacity-60">썸네일:</strong> {currentCredits.thumbnail}</div>
                      <div><strong className="opacity-60">홈페이지:</strong> {currentCredits.homepage}</div>
                      <div><strong className="opacity-60">펀딩 자금:</strong> {currentCredits.funding}</div>
                      <div className="col-span-2"><strong className="opacity-60">심리치료사:</strong> {currentCredits.therapist}</div>
                      <div className="col-span-2"><strong className="opacity-60">시간투자자:</strong> {currentCredits.investor}</div>
                  </div>
              </div>
          </div>
      )}

      {showShopModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4">
              <div className={`max-w-md w-full p-6 rounded-xl relative shadow-2xl transition-all ${state.entityEncounter ? 'bg-black border-4 border-red-900 text-red-600 font-serif' : (state.isDark ? 'bg-gray-900 text-white border border-gray-700' : 'bg-white')}`}>
                  <button onClick={() => setShowShopModal(false)} className="absolute top-4 right-4 hover:scale-110 transition-transform"><X /></button>
                  <h3 className={`text-xl font-bold mb-4 ${state.entityEncounter ? 'animate-pulse' : ''}`}>{state.entityEncounter ? "신체 포기 각서" : (state.isPurchased ? "구매 완료" : "데모 구입") }</h3>
                  
                  {state.isPurchased ? (
                    <div className="text-center space-y-4 py-8">
                       <CheckCircle size={64} className="mx-auto text-green-500 mb-4 animate-bounce" />
                       <p className="text-lg font-cute leading-relaxed">{SHOP_DATA.KR[shopMode].thanks}</p>
                       <button onClick={() => setShowShopModal(false)} className="px-6 py-2 bg-gray-200 dark:bg-gray-800 rounded-full font-bold hover:bg-gray-300 transition-colors">확인</button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <input type="text" placeholder="ID (필수)" value={shopInputs.id} onChange={e => setShopInputs(s => ({ ...s, id: e.target.value }))} className="w-full p-2 border rounded bg-transparent outline-none border-gray-300 dark:border-red-900" />
                      <input type="password" placeholder="PASSWORD (필수)" value={shopInputs.pw} onChange={e => setShopInputs(s => ({ ...s, pw: e.target.value }))} className="w-full p-2 border rounded bg-transparent outline-none border-gray-300 dark:border-red-900" />
                      <input type="text" placeholder="CARD NUMBER (필수)" value={shopInputs.card} onChange={e => setShopInputs(s => ({ ...s, card: e.target.value }))} className="w-full p-2 border rounded bg-transparent outline-none border-gray-300 dark:border-red-900" />
                      
                      <div className="space-y-2">
                        <label className="text-xs font-bold block opacity-70">{SHOP_DATA.KR[shopMode].termsTitle}</label>
                        <div ref={termsRef} onScroll={handleTermsScroll} className="h-24 overflow-y-auto p-2 text-[10px] border rounded leading-relaxed border-gray-200 dark:border-red-900">
                          {SHOP_DATA.KR[shopMode].termsContent}
                        </div>
                        <div className="flex items-center gap-2">
                          <input 
                            type="checkbox" 
                            id="terms" 
                            checked={state.entityEncounter ? true : termsAccepted} 
                            // Removed disabled attribute check for termsScrolled
                            onChange={() => setTermsAccepted(!termsAccepted)}
                            className="w-4 h-4 cursor-pointer"
                          />
                          <label htmlFor="terms" className="text-xs cursor-pointer">약관 동의 (스크롤 필수 아님)</label>
                        </div>
                      </div>

                      <button 
                        onClick={handlePurchase} 
                        // Removed !termsAccepted requirement if in Entity mode, but kept for normal for realism, though user asked to remove scroll requirement.
                        // Actually the user said "remove scroll requirement" for terms.
                        // I will keep termsAccepted check but the checkbox is no longer disabled by scroll.
                        disabled={state.entityEncounter ? false : (!shopInputs.id || !shopInputs.pw || !shopInputs.card || !termsAccepted)}
                        className={`w-full p-3 rounded-lg font-bold transition-all shadow-md active:scale-95 ${state.isDark ? 'bg-red-800 text-white' : 'bg-pink-50 text-white disabled:opacity-30'}`}
                      >
                        {state.entityEncounter ? "계약 이행" : "데모 구입"}
                      </button>
                    </div>
                  )}
              </div>
          </div>
      )}

      <InventoryBar 
        items={INVENTORY_ITEMS} 
        inventory={state.inventory} 
        onAddItem={handleAddItem}
        onInspectItem={handleInspectItem} 
        isGlitch={state.isGlitch} 
        isEntityEncounter={state.entityEncounter} 
        onReset={handleEntityReset} 
      />
    </div>
  );
}